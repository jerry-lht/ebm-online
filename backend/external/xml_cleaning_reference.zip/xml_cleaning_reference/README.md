# XML Cleaning Reference

这份代码包整理了 PMC/JATS XML 清洗相关代码，重点是把 XML 转成结构化 JSON：文章元数据、分节正文、原始表格 XML，以及清洗后的文本。

## 文件

- `code/clean_pmc_xml.py`: 最小独立脚本，清洗单个 PMC/JATS XML。
- `code/build_study_characteristics_xml_rob.py`: 原项目完整清洗脚本，读取 `rob_dataset`，拼接 study characteristics、XML 正文/表格、risk of bias 和 SR PICO。
- `code/build_study_xml_rob_dataset.py`: 上游脚本，负责准备 `rob_dataset` 和 XML/HTML 内容路径。
- `examples/sample_pmc.xml`: 可直接测试的迷你 XML。

## 最小用法

```bash
python3 code/clean_pmc_xml.py \
  --xml examples/sample_pmc.xml \
  --output output/sample_cleaned.json
```

输出 JSON 结构：

- `article_meta`: `pmcid`、`pmid`、`doi`、`title`
- `sections`: 按 XML section 组织后的正文文本
- `tables`: `table-wrap` 的原始 XML 和所在 section
- `paragraph_count` / `section_count` / `table_count`: 清洗统计

## 清洗规则

1. 去命名空间：`{namespace}p` 会被视为 `p`。
2. 文本清洗：HTML entity 解码、连续空白折叠、首尾空白去除。
3. 正文抽取：递归遍历 `<body>`，按 `<sec><title>` 建立 section path，只收集 `<p>` 文本。
4. 表格保留：遇到 `<table-wrap>` 时保存原始 XML，避免表格结构丢失。
5. 跳过噪声：默认跳过 figure、references、supplementary material 等标签。
6. back matter：只保留 funding、conflict of interest、ethics、trial registration 等常用声明类 section。

## 原项目完整流程

如果已经有 `rob_dataset`，可以运行：

```bash
python3 code/build_study_characteristics_xml_rob.py \
  --input-dir data/cochrane_reviews/rob_dataset \
  --output-dir data/cochrane_reviews/rob_cleaned_dataset
```

它会输出按 PMID/PMCID 命名的清洗后 study JSON，并生成 summary / unmatched 文件。
