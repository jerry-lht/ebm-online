# DOI to PMC XML Reference

这份代码包整理了“通过 DOI 获取 PMC XML”的核心流程，适合作为参考或单独复用。

## 文件

- `code/doi_to_pmc_xml.py`: 最小独立脚本。输入 DOI 列表，输出 PMC XML 文件和 `manifest.json`。
- `code/enrich_characteristics_with_pmc_xml.py`: 原项目脚本，用于给已链接的 Cochrane study JSON 补 DOI/PMID/PMCID、下载 XML、生成索引。
- `code/build_study_xml_rob_dataset.py`: 原项目脚本，用于构建按 SR 分组的数据集，优先使用 XML，失败时尝试 HTML fallback。
- `code/build_study_characteristics_xml_rob.py`: 后处理脚本，用于从 `rob_dataset` 继续整理 study characteristics / ROB 数据。
- `examples/dois.txt`: DOI 输入示例。

## 最小用法

```bash
python3 code/doi_to_pmc_xml.py \
  --doi-file examples/dois.txt \
  --output-dir output/pmc_xml
```

输出：

- `output/pmc_xml/PMCxxxx.xml`: 下载到的 PMC XML。
- `output/pmc_xml/manifest.json`: DOI 到 PMID/PMCID/XML 路径的映射。

## 核心逻辑

1. 规范化 DOI：去掉 `doi:`、`https://doi.org/`、尾部标点，并统一小写。
2. 调用 PMC ID Converter：
   `https://pmc.ncbi.nlm.nih.gov/tools/idconv/api/v1/articles/`
   将 DOI 映射为 PMID / PMCID。
3. 调用 NCBI EFetch：
   `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pmc&rettype=xml`
   根据 PMCID 批量下载 XML。
4. 拆分 EFetch 返回的 `pmc-articleset`，按 `PMCID.xml` 单独保存。

## 注意

- 只有进入 PMC 的文章才能拿到 PMCID 并下载 PMC XML。
- 有些记录只能拿到 front matter，没有正文 `<body>`，脚本会标记为 `front_matter_only`。
- 如果批量请求中有坏 DOI，脚本会把请求拆小，避免整批失败。
- 建议把 `PMC_EMAIL` 改成自己的邮箱，方便符合 NCBI 工具请求规范。
