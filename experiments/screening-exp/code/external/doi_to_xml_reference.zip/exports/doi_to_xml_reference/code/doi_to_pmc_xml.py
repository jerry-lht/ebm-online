#!/usr/bin/env python3

import argparse
import json
import re
import sys
import time
from copy import deepcopy
from pathlib import Path
from typing import Dict, Iterable, List
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import xml.etree.ElementTree as ET


USER_AGENT = "doi-to-pmc-xml-reference/0.1"
PMC_TOOL = "doi-to-pmc-xml-reference"
PMC_EMAIL = "example@example.com"
IDCONV_URL = "https://pmc.ncbi.nlm.nih.gov/tools/idconv/api/v1/articles/"
EFETCH_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"


def normalize_doi(value: str) -> str:
    text = (value or "").strip()
    text = text.replace("\ufeff", "").replace("\u200b", "")
    text = re.sub(r"^\s*doi\s*:\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"^\s*https?://(dx\.)?doi\.org/", "", text, flags=re.IGNORECASE)
    return text.strip().rstrip(" .;,").lower()


def chunked(items: List[str], size: int) -> Iterable[List[str]]:
    for start in range(0, len(items), size):
        yield items[start : start + size]


def http_get(url: str, timeout: int = 60, retries: int = 3) -> bytes:
    last_error = None
    for attempt in range(1, retries + 1):
        request = Request(url, headers={"User-Agent": USER_AGENT})
        try:
            with urlopen(request, timeout=timeout) as response:
                return response.read()
        except HTTPError as exc:
            last_error = exc
            if exc.code == 400:
                raise
            if attempt == retries:
                raise
            retry_after = exc.headers.get("Retry-After")
            delay = float(retry_after) if retry_after and retry_after.isdigit() else min(2**attempt, 30)
            time.sleep(delay)
        except Exception as exc:
            last_error = exc
            if attempt == retries:
                raise
            time.sleep(min(2 ** (attempt - 1), 8))
    raise RuntimeError(f"Unreachable: {last_error}")


def fetch_idconv_batch(dois: List[str]) -> Dict[str, dict]:
    params = {
        "ids": ",".join(dois),
        "idtype": "doi",
        "versions": "yes",
        "format": "json",
        "tool": PMC_TOOL,
        "email": PMC_EMAIL,
    }
    url = f"{IDCONV_URL}?{urlencode(params)}"
    try:
        payload = json.loads(http_get(url).decode("utf-8"))
    except HTTPError as exc:
        if exc.code == 400 and len(dois) > 1:
            midpoint = len(dois) // 2
            return {**fetch_idconv_batch(dois[:midpoint]), **fetch_idconv_batch(dois[midpoint:])}
        if exc.code == 400 and len(dois) == 1:
            return {}
        raise

    result = {}
    for record in payload.get("records", []):
        requested = normalize_doi(record.get("requested-id", ""))
        if not requested:
            continue
        result[requested] = {
            "doi": normalize_doi(record.get("doi", requested)),
            "pmid": str(record.get("pmid", "") or ""),
            "pmcid": str(record.get("pmcid", "") or "").upper(),
            "versions": record.get("versions", []),
            "source": "pmc_idconv",
        }
    return result


def article_pmcid(article: ET.Element) -> str:
    for node in article.findall(".//article-id[@pub-id-type='pmcid']"):
        value = (node.text or "").strip().upper()
        if value:
            return value
    return ""


def split_pmc_articles(xml_bytes: bytes) -> Dict[str, dict]:
    root = ET.fromstring(xml_bytes)
    articles = {}
    for article in root.findall("article"):
        pmcid = article_pmcid(article)
        if not pmcid:
            continue
        wrapper = ET.Element("pmc-articleset")
        wrapper.append(deepcopy(article))
        xml_text = ET.tostring(wrapper, encoding="unicode")
        articles[pmcid] = {
            "xml_text": '<?xml version="1.0" encoding="UTF-8"?>\n' + xml_text,
            "status": "full_text" if article.find("body") is not None else "front_matter_only",
        }
    return articles


def fetch_efetch_batch(pmcids: List[str]) -> Dict[str, dict]:
    params = {
        "db": "pmc",
        "id": ",".join(pmcids),
        "rettype": "xml",
        "tool": PMC_TOOL,
        "email": PMC_EMAIL,
    }
    url = f"{EFETCH_URL}?{urlencode(params)}"
    return split_pmc_articles(http_get(url, timeout=120))


def read_dois(path: Path) -> List[str]:
    seen = set()
    dois = []
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        doi = normalize_doi(line)
        if doi and not doi.startswith("#") and doi not in seen:
            dois.append(doi)
            seen.add(doi)
    return dois


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Resolve DOI to PMCID and download PMC XML.")
    parser.add_argument("--doi-file", required=True, help="One DOI per line.")
    parser.add_argument("--output-dir", default="pmc_xml", help="Directory for XML and manifest files.")
    parser.add_argument("--idconv-batch-size", type=int, default=100)
    parser.add_argument("--efetch-batch-size", type=int, default=50)
    parser.add_argument("--sleep-seconds", type=float, default=0.5)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    doi_file = Path(args.doi_file)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    dois = read_dois(doi_file)
    id_map = {}
    for batch in chunked(dois, args.idconv_batch_size):
        id_map.update(fetch_idconv_batch(batch))
        time.sleep(args.sleep_seconds)

    pmcids = sorted({item["pmcid"] for item in id_map.values() if item.get("pmcid")})
    xml_index = {}
    for batch in chunked(pmcids, args.efetch_batch_size):
        for pmcid, payload in fetch_efetch_batch(batch).items():
            xml_path = output_dir / f"{pmcid}.xml"
            xml_path.write_text(payload["xml_text"], encoding="utf-8")
            xml_index[pmcid] = {
                "path": str(xml_path.resolve()),
                "status": payload["status"],
                "source": "ncbi_efetch",
            }
        time.sleep(args.sleep_seconds)

    manifest = {
        "doi_file": str(doi_file.resolve()),
        "doi_count": len(dois),
        "resolved_count": len(id_map),
        "pmcid_count": len(pmcids),
        "xml_count": len(xml_index),
        "id_map": id_map,
        "xml_index": xml_index,
    }
    (output_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: manifest[k] for k in ("doi_count", "resolved_count", "pmcid_count", "xml_count")}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
