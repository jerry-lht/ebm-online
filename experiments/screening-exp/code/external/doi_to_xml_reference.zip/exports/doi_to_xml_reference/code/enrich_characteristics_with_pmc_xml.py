#!/usr/bin/env python3

import argparse
import csv
import json
import re
import sys
import time
from copy import deepcopy
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import xml.etree.ElementTree as ET


ET.register_namespace("xlink", "http://www.w3.org/1999/xlink")

USER_AGENT = "codex-sr-cleaned/0.1"
PMC_TOOL = "codex"
PMC_EMAIL = "example@example.com"
IDCONV_URL = "https://pmc.ncbi.nlm.nih.gov/tools/idconv/api/v1/articles/"
EFETCH_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"

CATEGORY_TO_RIS_SUFFIX = {
    "included": "included",
    "excluded": "excluded",
    "ongoing": "ongoing",
    "awaiting_classification": "awaiting",
}

CSV_RAW_FIELD_MAP = {
    "Char: Methods": "methods",
    "Char: Participants": "participants",
    "Char: Interventions": "interventions",
    "Char: Outcomes": "outcomes",
    "Char: Notes": "notes",
}

PMCID_RE = re.compile(r"\bPMC\d+\b", re.IGNORECASE)
PMID_RE = re.compile(r"\b\d{5,9}\b")
PROJECT_ROOT = Path(__file__).resolve().parent.parent


def default_path(*parts: str) -> str:
    return str(PROJECT_ROOT.joinpath(*parts))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Restore raw characteristics markup from local Cochrane data packages, "
            "resolve DOI->PMID->PMCID, and fetch PMC XML for linked study records."
        )
    )
    parser.add_argument(
        "--source-dir",
        default=default_path(
            "data", "cochrane_reviews", "linked_reviews_dedup_doi"
        ),
        help="Directory with linked study JSON files.",
    )
    parser.add_argument(
        "--data-package-dir",
        default=default_path("data", "cochrane_data_package", "zip"),
        help="Directory with unpacked Cochrane data packages.",
    )
    parser.add_argument(
        "--output-dir",
        default=default_path(
            "data", "cochrane_reviews", "linked_reviews_dedup_doi_pmc_xml"
        ),
        help="Directory to write enriched review JSON files.",
    )
    parser.add_argument(
        "--xml-dir",
        default=default_path("data", "cochrane_reviews", "pmc_xml"),
        help="Directory to write raw PMC XML files.",
    )
    parser.add_argument(
        "--review-glob",
        default="*.json",
        help="Glob for review JSON files inside source-dir.",
    )
    parser.add_argument(
        "--limit-reviews",
        type=int,
        default=None,
        help="Optional limit on number of review files to process.",
    )
    parser.add_argument(
        "--idconv-batch-size",
        type=int,
        default=100,
        help="Batch size for PMC idconv requests.",
    )
    parser.add_argument(
        "--efetch-batch-size",
        type=int,
        default=50,
        help="Batch size for PMC efetch XML requests.",
    )
    parser.add_argument(
        "--sleep-seconds",
        type=float,
        default=0.5,
        help="Delay between remote requests.",
    )
    parser.add_argument(
        "--overwrite-xml",
        action="store_true",
        help="Re-fetch XML even if a local XML file already exists.",
    )
    parser.add_argument(
        "--summary-path",
        default=None,
        help="Optional explicit path for summary JSON.",
    )
    parser.add_argument(
        "--skip-review-json",
        action="store_true",
        help="Do not write enriched review JSON files; only write XML, caches, and index artifacts.",
    )
    parser.add_argument(
        "--study-index-path",
        default=None,
        help="Optional JSONL index path for study-to-XML mappings.",
    )
    return parser.parse_args()


def normalize_doi(value: str) -> str:
    text = (value or "").strip()
    if not text:
        return ""
    text = text.replace("\u200b", "").replace("\ufeff", "")
    text = re.sub(r"^\s*doi\s*:\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"^\s*https?://(dx\.)?doi\.org/", "", text, flags=re.IGNORECASE)
    return text.strip().rstrip(" .;,").lower()


def slugify_study_id(value: str) -> str:
    text = (value or "").strip().lower()
    text = text.replace("\u2010", "-").replace("\u2011", "-").replace("\u2012", "-")
    text = text.replace("\u2013", "-").replace("\u2014", "-").replace("\u2212", "-")
    text = re.sub(r"\s+", " ", text)
    return text


def load_json(path: Path):
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def dump_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


def dump_jsonl(path: Path, rows: Iterable[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False))
            handle.write("\n")


def http_get(url: str, timeout: int = 60, retries: int = 3) -> bytes:
    last_error = None
    for attempt in range(1, retries + 1):
        request = Request(url, headers={"User-Agent": USER_AGENT})
        try:
            with urlopen(request, timeout=timeout) as response:
                return response.read()
        except HTTPError as exc:
            last_error = exc
            if exc.code == 400:
                raise
            if attempt == retries:
                raise
            retry_after = exc.headers.get("Retry-After")
            if retry_after and retry_after.isdigit():
                delay = float(retry_after)
            else:
                delay = min(2 ** attempt, 30)
            time.sleep(delay)
        except Exception as exc:  # pragma: no cover - network path
            last_error = exc
            if attempt == retries:
                raise
            time.sleep(min(2 ** (attempt - 1), 8))
    raise RuntimeError(f"Unreachable: {last_error}")


def parse_ris_file(path: Path) -> List[dict]:
    text = path.read_text(encoding="utf-8-sig")
    records: List[dict] = []
    current: Dict[str, List[str]] = {}
    last_tag = None
    for raw_line in text.splitlines():
        line = raw_line.rstrip("\n")
        if not line.strip():
            continue
        if line.startswith("ER"):
            if current:
                records.append(current)
                current = {}
                last_tag = None
            continue
        if len(line) >= 6 and line[2:6] == "  - ":
            tag = line[:2]
            value = line[6:].strip()
            current.setdefault(tag, []).append(value)
            last_tag = tag
            continue
        if last_tag is not None:
            current[last_tag][-1] = f"{current[last_tag][-1]} {line.strip()}".strip()
    if current:
        records.append(current)
    return records


def extract_ids_from_ris_record(record: dict) -> dict:
    doi = ""
    pmid = ""
    pmcid = ""
    study_id = ""
    if "DO" in record and record["DO"]:
        doi = record["DO"][0].strip()
    if "NS" in record and record["NS"]:
        study_id = record["NS"][0].strip()
    for value in record.get("C3", []):
        pmcid_match = PMCID_RE.search(value)
        if pmcid_match and not pmcid:
            pmcid = pmcid_match.group(0).upper()
        if ("PubMed" in value or "PMID" in value) and not pmid:
            pmid_match = PMID_RE.search(value)
            if pmid_match:
                pmid = pmid_match.group(0)
    return {
        "study_id": study_id,
        "doi": doi,
        "pmid": pmid,
        "pmcid": pmcid,
    }


def build_ris_maps(review_id: str, data_package_dir: Path) -> Dict[str, dict]:
    study_data_dir = data_package_dir / review_id / "study-data"
    result: Dict[str, dict] = {}
    for category, suffix in CATEGORY_TO_RIS_SUFFIX.items():
        path = study_data_dir / f"{review_id}-{suffix}.ris"
        by_study: Dict[str, dict] = {}
        by_doi: Dict[str, dict] = {}
        if path.exists():
            for record in parse_ris_file(path):
                item = extract_ids_from_ris_record(record)
                study_key = slugify_study_id(item["study_id"])
                doi_key = normalize_doi(item["doi"])
                if study_key:
                    by_study[study_key] = item
                if doi_key:
                    by_doi[doi_key] = item
        result[category] = {
            "path": str(path),
            "by_study": by_study,
            "by_doi": by_doi,
        }
    return result


def build_raw_characteristics_map(review_id: str, data_package_dir: Path) -> Dict[str, dict]:
    csv_path = data_package_dir / review_id / "study-data" / f"{review_id}-study-information.csv"
    if not csv_path.exists():
        return {}
    result: Dict[str, dict] = {}
    with csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            study_key = slugify_study_id(row.get("Study", ""))
            if not study_key:
                continue
            raw_fields = {
                target_key: (row.get(source_key) or "")
                for source_key, target_key in CSV_RAW_FIELD_MAP.items()
            }
            result[study_key] = {
                "source_path": str(csv_path),
                "fields": raw_fields,
            }
    return result


def iter_studies(review_data: dict) -> Iterable[Tuple[str, int, dict]]:
    studies_by_category = review_data.get("studies_by_category", {})
    for category, payload in studies_by_category.items():
        studies = payload.get("studies", [])
        for index, study in enumerate(studies):
            yield category, index, study


def chunked(items: List[str], size: int) -> Iterable[List[str]]:
    for start in range(0, len(items), size):
        yield items[start : start + size]


def load_cache(path: Path) -> dict:
    if not path.exists():
        return {}
    return load_json(path)


def save_cache(path: Path, cache: dict) -> None:
    dump_json(path, cache)


def fetch_idconv_batch(dois: List[str]) -> dict:
    params = {
        "ids": ",".join(dois),
        "idtype": "doi",
        "versions": "yes",
        "format": "json",
        "tool": PMC_TOOL,
        "email": PMC_EMAIL,
    }
    url = f"{IDCONV_URL}?{urlencode(params)}"
    try:
        payload = json.loads(http_get(url).decode("utf-8"))
    except HTTPError as exc:
        if exc.code == 400 and len(dois) > 1:
            midpoint = len(dois) // 2
            left = fetch_idconv_batch(dois[:midpoint])
            right = fetch_idconv_batch(dois[midpoint:])
            merged = {}
            merged.update(left)
            merged.update(right)
            return merged
        if exc.code == 400 and len(dois) == 1:
            return {}
        raise
    records = payload.get("records", [])
    result = {}
    for record in records:
        requested = normalize_doi(record.get("requested-id", ""))
        if not requested:
            continue
        result[requested] = {
            "doi": normalize_doi(record.get("doi", requested)),
            "pmid": str(record.get("pmid", "") or ""),
            "pmcid": str(record.get("pmcid", "") or "").upper(),
            "versions": record.get("versions", []),
            "source": "pmc_idconv",
        }
    return result


def article_pmcid(article: ET.Element) -> str:
    for node in article.findall(".//article-id[@pub-id-type='pmcid']"):
        value = (node.text or "").strip().upper()
        if value:
            return value
    return ""


def article_has_body(article: ET.Element) -> bool:
    return article.find("body") is not None


def split_pmc_articles(xml_bytes: bytes) -> Dict[str, dict]:
    root = ET.fromstring(xml_bytes)
    articles = {}
    for article in root.findall("article"):
        pmcid = article_pmcid(article)
        if not pmcid:
            continue
        wrapper = ET.Element("pmc-articleset")
        wrapper.append(deepcopy(article))
        xml_text = ET.tostring(wrapper, encoding="unicode")
        xml_text = '<?xml version="1.0" encoding="UTF-8"?>\n' + xml_text
        articles[pmcid] = {
            "xml_text": xml_text,
            "status": "full_text" if article_has_body(article) else "front_matter_only",
        }
    return articles


def fetch_efetch_batch(pmcids: List[str]) -> Dict[str, dict]:
    params = {
        "db": "pmc",
        "id": ",".join(pmcids),
        "rettype": "xml",
        "tool": PMC_TOOL,
        "email": PMC_EMAIL,
    }
    url = f"{EFETCH_URL}?{urlencode(params)}"
    return split_pmc_articles(http_get(url, timeout=120))


def main() -> int:
    args = parse_args()
    source_dir = Path(args.source_dir)
    data_package_dir = Path(args.data_package_dir)
    output_dir = Path(args.output_dir)
    xml_dir = Path(args.xml_dir)
    summary_path = Path(args.summary_path) if args.summary_path else output_dir / "_summary.json"
    study_index_path = Path(args.study_index_path) if args.study_index_path else xml_dir / "_study_index.jsonl"
    idconv_cache_path = output_dir / "_idconv_cache.json"
    xml_index_path = output_dir / "_pmc_xml_index.json"

    review_paths = sorted(
        path for path in source_dir.glob(args.review_glob) if path.is_file() and not path.name.startswith("_")
    )
    if args.limit_reviews is not None:
        review_paths = review_paths[: args.limit_reviews]

    idconv_cache = load_cache(idconv_cache_path)
    xml_index = load_cache(xml_index_path)

    pending_dois: List[str] = []
    pending_doi_set = set()
    unique_pmcids = set()
    enriched_reviews = {}
    stats = {
        "reviews_processed": 0,
        "studies_processed": 0,
        "studies_with_doi": 0,
        "studies_with_pmid": 0,
        "studies_with_pmcid": 0,
        "included_with_raw_characteristics_html": 0,
        "pmc_xml_full_text": 0,
        "pmc_xml_front_matter_only": 0,
        "pmc_xml_missing": 0,
    }

    for review_path in review_paths:
        review_data = load_json(review_path)
        review_id = review_data.get("sr_meta", {}).get("cd_number") or review_path.stem.split("_")[0]
        ris_maps = build_ris_maps(review_id, data_package_dir)
        raw_char_map = build_raw_characteristics_map(review_id, data_package_dir)

        for category, _, study in iter_studies(review_data):
            stats["studies_processed"] += 1
            study_key = slugify_study_id(study.get("study_id", ""))
            doi = normalize_doi(study.get("doi", ""))
            pmid = str(study.get("pmid", "") or "")
            pmcid = str(study.get("pmcid", "") or "").upper()

            ris_lookup = ris_maps.get(category, {})
            local_match = ris_lookup.get("by_study", {}).get(study_key)
            if local_match is None and doi:
                local_match = ris_lookup.get("by_doi", {}).get(doi)

            if local_match:
                if not doi and local_match.get("doi"):
                    doi = normalize_doi(local_match["doi"])
                    study["doi"] = doi
                if not pmid and local_match.get("pmid"):
                    pmid = local_match["pmid"]
                    study["pmid"] = pmid
                if not pmcid and local_match.get("pmcid"):
                    pmcid = local_match["pmcid"]
                    study["pmcid"] = pmcid
                study["id_lookup_source"] = "local_ris"

            if category == "included" and study_key in raw_char_map:
                study["characteristics_raw_html"] = raw_char_map[study_key]["fields"]
                study["characteristics_raw_html_source"] = raw_char_map[study_key]["source_path"]
                stats["included_with_raw_characteristics_html"] += 1

            if doi:
                stats["studies_with_doi"] += 1
                if (not pmid or not pmcid) and doi not in idconv_cache and doi not in pending_doi_set:
                    pending_dois.append(doi)
                    pending_doi_set.add(doi)

            if pmid:
                stats["studies_with_pmid"] += 1
            if pmcid:
                unique_pmcids.add(pmcid)
                stats["studies_with_pmcid"] += 1

        enriched_reviews[review_path.name] = review_data
        stats["reviews_processed"] += 1

    for batch in chunked(pending_dois, args.idconv_batch_size):
        batch_result = fetch_idconv_batch(batch)
        idconv_cache.update(batch_result)
        save_cache(idconv_cache_path, idconv_cache)
        time.sleep(args.sleep_seconds)

    # Apply remote DOI mappings after the cache is filled.
    unique_pmcids = set()
    stats["studies_with_pmid"] = 0
    stats["studies_with_pmcid"] = 0
    for review_name, review_data in enriched_reviews.items():
        for _, _, study in iter_studies(review_data):
            doi = normalize_doi(study.get("doi", ""))
            pmid = str(study.get("pmid", "") or "")
            pmcid = str(study.get("pmcid", "") or "").upper()
            cache_hit = idconv_cache.get(doi, {}) if doi else {}
            if doi and cache_hit:
                if not pmid and cache_hit.get("pmid"):
                    pmid = cache_hit["pmid"]
                    study["pmid"] = pmid
                if not pmcid and cache_hit.get("pmcid"):
                    pmcid = cache_hit["pmcid"]
                    study["pmcid"] = pmcid
                if study.get("id_lookup_source") != "local_ris":
                    study["id_lookup_source"] = cache_hit.get("source", "pmc_idconv")
            if pmid:
                stats["studies_with_pmid"] += 1
            if pmcid:
                stats["studies_with_pmcid"] += 1
                unique_pmcids.add(pmcid)

    xml_dir.mkdir(parents=True, exist_ok=True)
    pmcids_to_fetch = []
    for pmcid in sorted(unique_pmcids):
        xml_path = xml_dir / f"{pmcid}.xml"
        if not args.overwrite_xml and xml_path.exists():
            if pmcid not in xml_index:
                text = xml_path.read_text(encoding="utf-8")
                xml_index[pmcid] = {
                    "path": str(xml_path),
                    "status": "full_text" if "<body" in text else "front_matter_only",
                    "source": "ncbi_efetch",
                }
            continue
        pmcids_to_fetch.append(pmcid)

    for batch in chunked(pmcids_to_fetch, args.efetch_batch_size):
        batch_result = fetch_efetch_batch(batch)
        for pmcid, payload in batch_result.items():
            xml_path = xml_dir / f"{pmcid}.xml"
            xml_path.write_text(payload["xml_text"], encoding="utf-8")
            xml_index[pmcid] = {
                "path": str(xml_path),
                "status": payload["status"],
                "source": "ncbi_efetch",
            }
        save_cache(xml_index_path, xml_index)
        time.sleep(args.sleep_seconds)

    study_index_rows = []
    for review_name, review_data in enriched_reviews.items():
        review_meta = review_data.get("sr_meta", {})
        for _, _, study in iter_studies(review_data):
            pmcid = str(study.get("pmcid", "") or "").upper()
            if not pmcid:
                study["pmc_xml_status"] = "missing_pmcid"
                stats["pmc_xml_missing"] += 1
                continue
            entry = xml_index.get(pmcid)
            if not entry:
                study["pmc_xml_status"] = "missing_xml"
                stats["pmc_xml_missing"] += 1
                continue
            study["pmc_xml_path"] = entry["path"]
            study["pmc_xml_status"] = entry["status"]
            study["pmc_xml_source"] = entry.get("source", "ncbi_efetch")
            if entry["status"] == "full_text":
                stats["pmc_xml_full_text"] += 1
            else:
                stats["pmc_xml_front_matter_only"] += 1

            study_index_rows.append(
                {
                    "review_file": review_name,
                    "review_id": review_meta.get("id", ""),
                    "cd_number": review_meta.get("cd_number", ""),
                    "review_title": review_meta.get("title", ""),
                    "category": next(
                        (
                            category
                            for category, payload in review_data.get("studies_by_category", {}).items()
                            if study in payload.get("studies", [])
                        ),
                        "",
                    ),
                    "study_id": study.get("study_id", ""),
                    "doi": study.get("doi", ""),
                    "pmid": study.get("pmid", ""),
                    "pmcid": study.get("pmcid", ""),
                    "pmc_xml_path": study.get("pmc_xml_path", ""),
                    "pmc_xml_status": study.get("pmc_xml_status", ""),
                }
            )

        if not args.skip_review_json:
            dump_json(output_dir / review_name, review_data)

    dump_jsonl(study_index_path, study_index_rows)

    summary = {
        "generated_at_epoch": int(time.time()),
        "source_dir": str(source_dir),
        "data_package_dir": str(data_package_dir),
        "output_dir": str(output_dir),
        "xml_dir": str(xml_dir),
        "study_index_path": str(study_index_path),
        "skip_review_json": args.skip_review_json,
        "stats": stats,
        "unique_pmcs": {
            "with_pmcid": len(unique_pmcids),
            "xml_cached_or_fetched": len(xml_index),
        },
        "artifacts": {
            "idconv_cache": str(idconv_cache_path),
            "xml_index": str(xml_index_path),
        },
    }
    dump_json(summary_path, summary)
    return 0


if __name__ == "__main__":
    sys.exit(main())
