#!/usr/bin/env python3

import argparse
import html
import json
import re
import sys
import unicodedata
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_INPUT_DIR = PROJECT_ROOT / "data" / "cochrane_reviews" / "rob_dataset"
DEFAULT_OUTPUT_DIR = (
    PROJECT_ROOT / "data" / "cochrane_reviews" / "rob_cleaned_dataset"
)
DEFAULT_SUMMARY_PATH = DEFAULT_OUTPUT_DIR / "_study_characteristics_xml_rob_summary.json"
DEFAULT_OUTPUT_SUFFIX = ".json"
DEFAULT_UNMATCHED_PATH = DEFAULT_OUTPUT_DIR / "_study_characteristics_xml_rob_unmatched.json"

SKIP_XML_TAGS = {
    "fig",
    "ref-list",
    "back",
    "ack",
    "app-group",
    "supplementary-material",
}

BACK_MATTER_SECTION_TITLE_MAP = {
    "acknowledgement": "Acknowledgements",
    "acknowledgements": "Acknowledgements",
    "acknowledgment": "Acknowledgements",
    "acknowledgments": "Acknowledgements",
    "funding": "Funding",
    "funding statement": "Funding",
    "financial support": "Funding",
    "competing interests": "Conflict of Interest",
    "conflicts of interest": "Conflict of Interest",
    "conflict of interest": "Conflict of Interest",
    "data availability": "Data Availability",
    "data availability statement": "Data Availability",
    "availability of data and materials": "Data Availability",
    "ethics statements": "Ethics",
    "ethics statement": "Ethics",
    "ethics approval and consent to participate": "Ethics",
    "institutional review board statement": "Ethics",
    "informed consent statement": "Ethics",
    "author contributions": "Author Contributions",
    "authors contributions": "Author Contributions",
    "trial registration": "Trial Registration",
    "declarations": "Declarations",
}

BACK_MATTER_SEC_TYPE_MAP = {
    "coi statement": "Conflict of Interest",
    "conflict": "Conflict of Interest",
    "data availability": "Data Availability",
    "ethics statement": "Ethics",
    "funding information": "Funding",
    "trial registration": "Trial Registration",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Build per-review cleaned JSON files that join included+xml study "
            "records with characteristics, XML paragraphs/tables, and risk of bias."
        )
    )
    parser.add_argument(
        "--input-dir",
        default=str(DEFAULT_INPUT_DIR),
        help="Directory containing the existing rob_dataset review folders.",
    )
    parser.add_argument(
        "--output-dir",
        default=str(DEFAULT_OUTPUT_DIR),
        help="Directory to write the cleaned review-organized dataset.",
    )
    parser.add_argument(
        "--output-suffix",
        default=DEFAULT_OUTPUT_SUFFIX,
        help="Suffix for each per-review output file, written as <SR_ID><suffix>.",
    )
    parser.add_argument(
        "--summary-path",
        default=str(DEFAULT_SUMMARY_PATH),
        help="Path to the global summary JSON.",
    )
    parser.add_argument(
        "--unmatched-path",
        default=str(DEFAULT_UNMATCHED_PATH),
        help="Path to the unmatched studies JSON.",
    )
    parser.add_argument(
        "--limit-reviews",
        type=int,
        default=None,
        help="Optional limit for testing.",
    )
    return parser.parse_args()


def load_json(path: Path):
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def dump_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


def normalize_study_id(value: str) -> str:
    text = unicodedata.normalize("NFKC", (value or "").strip())
    text = text.lower()
    text = text.replace("\u2010", "-").replace("\u2011", "-").replace("\u2012", "-")
    text = text.replace("\u2013", "-").replace("\u2014", "-").replace("\u2212", "-")
    text = re.sub(r"\s+", " ", text)
    return text


def clean_text(value: str) -> str:
    text = html.unescape(value or "")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def normalize_label(value: str) -> str:
    text = unicodedata.normalize("NFKC", value or "")
    text = text.replace("\u2018", "'").replace("\u2019", "'")
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def html_fragment_to_text(value: str) -> str:
    if not value:
        return ""
    text = value
    text = re.sub(r"(?i)<\s*br\s*/?\s*>", "\n", text)
    text = re.sub(r"(?i)</\s*p\s*>", "\n", text)
    text = re.sub(r"(?i)</\s*li\s*>", "\n", text)
    text = re.sub(r"(?i)</\s*tr\s*>", "\n", text)
    text = re.sub(r"(?i)</\s*div\s*>", "\n", text)
    text = re.sub(r"<[^>]+>", "", text)
    text = html.unescape(text)
    lines = [re.sub(r"\s+", " ", line).strip() for line in text.splitlines()]
    lines = [line for line in lines if line]
    return "\n".join(lines)


def xml_tag_name(tag: str) -> str:
    if "}" in tag:
        return tag.rsplit("}", 1)[-1]
    return tag


def direct_child_text(node: ET.Element, child_name: str) -> str:
    for child in node:
        if xml_tag_name(child.tag) == child_name:
            return clean_text("".join(child.itertext()))
    return ""


def xml_to_string(node: ET.Element) -> str:
    return ET.tostring(node, encoding="unicode")


def iter_review_dirs(input_dir: Path) -> Iterable[Path]:
    for path in sorted(input_dir.iterdir()):
        if not path.is_dir():
            continue
        if (path / "sr" / "source_review.json").exists():
            yield path


def build_characteristic_maps(
    included_items: Sequence[dict],
) -> Tuple[Dict[str, List[dict]], List[Tuple[str, dict]]]:
    exact_map: Dict[str, List[dict]] = {}
    normalized_items: List[Tuple[str, dict]] = []
    for item in included_items:
        if not isinstance(item, dict):
            continue
        normalized = normalize_study_id(item.get("study_id", ""))
        if not normalized:
            continue
        exact_map.setdefault(normalized, []).append(item)
        normalized_items.append((normalized, item))
    return exact_map, normalized_items


def match_characteristic(
    study_id: str,
    exact_map: Dict[str, List[dict]],
    normalized_items: Sequence[Tuple[str, dict]],
) -> Tuple[str, str, Optional[dict]]:
    normalized = normalize_study_id(study_id)
    exact_candidates = exact_map.get(normalized, [])
    if len(exact_candidates) == 1:
        return normalized, "exact_normalized", exact_candidates[0]
    if len(exact_candidates) > 1:
        return normalized, "unmatched", None

    suffix_candidates = [
        item for item_normalized, item in normalized_items if item_normalized.endswith(normalized)
    ]
    if len(suffix_candidates) == 1:
        return normalized, "suffix_normalized", suffix_candidates[0]
    return normalized, "unmatched", None


def normalize_study_risk_of_bias(raw_items: Sequence[dict]) -> List[dict]:
    normalized = []
    for item in raw_items or []:
        if not isinstance(item, dict):
            continue
        domain = clean_text(item.get("domain", ""))
        judgement = clean_text(item.get("judgement", ""))
        support_text = html_fragment_to_text(item.get("support", ""))
        if not domain and not judgement and not support_text:
            continue
        normalized.append(
            {
                "domain": domain,
                "judgement": judgement,
                "support_text": support_text,
                "source": "study_json",
            }
        )
    return normalized


def normalize_characteristics_risk_of_bias(raw_items: Sequence[dict]) -> List[dict]:
    normalized = []
    for item in raw_items or []:
        if not isinstance(item, dict):
            continue
        domain = clean_text(item.get("bias", ""))
        judgement = clean_text(item.get("judgement", ""))
        support_text = clean_text(item.get("support", ""))
        if not domain and not judgement and not support_text:
            continue
        normalized.append(
            {
                "domain": domain,
                "judgement": judgement,
                "support_text": support_text,
                "source": "source_review_characteristics",
            }
        )
    return normalized


def select_risk_of_bias(study_record: dict, characteristic: Optional[dict]) -> List[dict]:
    normalized = normalize_study_risk_of_bias(study_record.get("risk_of_bias", []))
    if normalized:
        return normalized
    if characteristic is None:
        return []
    return normalize_characteristics_risk_of_bias(characteristic.get("risk_of_bias", []))


def build_characteristics_payload(characteristic: dict) -> dict:
    return {
        "methods": characteristic.get("methods", "") or "",
        "participants": characteristic.get("participants", "") or "",
        "interventions": characteristic.get("interventions", "") or "",
        "outcomes": characteristic.get("outcomes", "") or "",
        "notes": characteristic.get("notes", "") or "",
    }


def normalize_sr_pico(raw_pico: Optional[dict]) -> dict:
    normalized = {}
    pico = raw_pico if isinstance(raw_pico, dict) else {}
    for key in ("population", "intervention", "comparison", "outcome"):
        values = pico.get(key, [])
        cleaned_values: List[str] = []
        if isinstance(values, list):
            for item in values:
                if isinstance(item, str):
                    text = clean_text(item)
                elif isinstance(item, dict):
                    text = clean_text(
                        item.get("text", "")
                        or item.get("label", "")
                        or item.get("name", "")
                    )
                else:
                    text = clean_text(str(item))
                if text:
                    cleaned_values.append(text)
        normalized[key] = cleaned_values
    return normalized


def extract_xml_content(xml_path: Path) -> dict:
    root = ET.parse(xml_path).getroot()
    article = root.find("article")
    if article is None:
        article = root

    paragraphs: List[dict] = []
    tables: List[dict] = []

    body = article.find("body")
    if body is not None:
        walk_xml_node(body, [], paragraphs, tables)

    for back in article.findall("back"):
        walk_back_matter(back, paragraphs, tables)

    for floats_group in article.findall("floats-group"):
        walk_float_tables(floats_group, ["floats-group"], tables)

    return {
        "sections": build_markdown_sections(paragraphs),
        "tables": tables,
        "_paragraph_count": len(paragraphs),
    }


def canonical_back_section_name(node: ET.Element) -> Optional[str]:
    tag = xml_tag_name(node.tag)
    title = direct_child_text(node, "title")
    title_key = normalize_label(title)
    if title_key in BACK_MATTER_SECTION_TITLE_MAP:
        return BACK_MATTER_SECTION_TITLE_MAP[title_key]

    sec_type_key = normalize_label(node.attrib.get("sec-type", ""))
    if sec_type_key in BACK_MATTER_SEC_TYPE_MAP:
        return BACK_MATTER_SEC_TYPE_MAP[sec_type_key]

    if tag == "ack":
        return "Acknowledgements"
    return None


def back_matter_text_fallback(node: ET.Element, title: str) -> str:
    chunks: List[str] = []
    if clean_text(node.text or ""):
        chunks.append(clean_text(node.text or ""))
    for child in node:
        if xml_tag_name(child.tag) == "title":
            if clean_text(child.tail or ""):
                chunks.append(clean_text(child.tail or ""))
            continue
        if clean_text(child.tail or ""):
            chunks.append(clean_text(child.tail or ""))
    text = " ".join(chunk for chunk in chunks if chunk).strip()
    if title and text.lower().startswith(title.lower()):
        text = text[len(title):].strip(" :.-")
    return text


def walk_back_matter(
    back: ET.Element,
    paragraphs: List[dict],
    tables: List[dict],
) -> None:
    for child in back:
        tag = xml_tag_name(child.tag)
        if tag not in {"ack", "notes", "sec"}:
            continue

        section_name = canonical_back_section_name(child)
        if not section_name:
            continue

        section_path = [section_name]
        paragraph_start = len(paragraphs)
        table_start = len(tables)
        raw_title = direct_child_text(child, "title")

        for grandchild in child:
            if xml_tag_name(grandchild.tag) == "title":
                continue
            walk_xml_node(grandchild, list(section_path), paragraphs, tables)

        if len(paragraphs) == paragraph_start and len(tables) == table_start:
            fallback_text = back_matter_text_fallback(child, raw_title)
            if fallback_text:
                paragraphs.append(
                    {
                        "section_path": section_path,
                        "text": fallback_text,
                    }
                )


def walk_xml_node(
    node: ET.Element,
    section_path: List[str],
    paragraphs: List[dict],
    tables: List[dict],
) -> None:
    tag = xml_tag_name(node.tag)
    if tag in SKIP_XML_TAGS:
        return

    if tag == "sec":
        title = direct_child_text(node, "title")
        next_path = section_path + [title] if title else list(section_path)
        for child in node:
            if xml_tag_name(child.tag) == "title":
                continue
            walk_xml_node(child, next_path, paragraphs, tables)
        return

    if tag == "p":
        text = clean_text("".join(node.itertext()))
        if text:
            paragraphs.append(
                {
                    "section_path": list(section_path),
                    "text": text,
                }
            )
        return

    if tag == "table-wrap":
        tables.append(
            {
                "section_path": list(section_path),
                "raw_xml": xml_to_string(node),
            }
        )
        return

    for child in node:
        walk_xml_node(child, list(section_path), paragraphs, tables)


def walk_float_tables(
    node: ET.Element,
    section_path: List[str],
    tables: List[dict],
) -> None:
    tag = xml_tag_name(node.tag)
    if tag == "table-wrap":
        tables.append(
            {
                "section_path": list(section_path),
                "raw_xml": xml_to_string(node),
            }
        )
        return
    for child in node:
        walk_float_tables(child, list(section_path), tables)


def markdown_heading(level: int, title: str) -> str:
    return f'{"#" * level} {title}'


def build_markdown_sections(paragraphs: Sequence[dict]) -> List[dict]:
    sections: List[dict] = []
    current_section_name: Optional[str] = None
    current_section_record: Optional[dict] = None
    current_subpath: Optional[Tuple[str, ...]] = None

    for paragraph in paragraphs:
        section_path = [part for part in paragraph.get("section_path", []) if part]
        text = paragraph.get("text", "") or ""
        if not text:
            continue

        section_name = section_path[0] if section_path else "Front"
        subpath = tuple(section_path[1:])

        if section_name != current_section_name:
            current_section_record = {"section": section_name, "text": ""}
            sections.append(current_section_record)
            current_section_name = section_name
            current_subpath = None

        if current_section_record is None:
            continue

        chunks: List[str] = []

        if subpath and subpath != current_subpath:
            for idx, title in enumerate(subpath):
                chunks.append(markdown_heading(idx + 2, title))
            current_subpath = subpath
        elif not subpath:
            current_subpath = None

        chunks.append(text)
        chunk_text = "\n\n".join(chunks)
        if current_section_record["text"]:
            current_section_record["text"] = f'{current_section_record["text"]}\n\n{chunk_text}'
        else:
            current_section_record["text"] = chunk_text

    return sections


def build_matched_study_record(
    study_record: dict,
    normalized_study_id: str,
    match_method: str,
    characteristic: dict,
    xml_content: dict,
    sr_pico: dict,
) -> dict:
    return {
        "study_id": study_record.get("study_id", ""),
        "study_id_normalized": normalized_study_id,
        "match_status": "matched",
        "match_method": match_method,
        "doi": study_record.get("doi", "") or "",
        "pmid": study_record.get("pmid", "") or "",
        "pmcid": study_record.get("pmcid", "") or "",
        "risk_of_bias": select_risk_of_bias(study_record, characteristic),
        "sr_pico": sr_pico,
        "characteristics": build_characteristics_payload(characteristic),
        "xml_content": {
            "sections": xml_content["sections"],
            "tables": xml_content["tables"],
        },
    }


def build_unmatched_study_record(
    study_record: dict,
    normalized_study_id: str,
    reason: str,
) -> dict:
    return {
        "study_id": study_record.get("study_id", ""),
        "study_id_normalized": normalized_study_id,
        "match_status": "unmatched",
        "match_method": "unmatched",
        "doi": study_record.get("doi", "") or "",
        "pmid": study_record.get("pmid", "") or "",
        "pmcid": study_record.get("pmcid", "") or "",
        "reason": reason,
    }


def candidate_study_paths(review_dir: Path) -> Iterable[Path]:
    studies_dir = review_dir / "studies"
    for path in sorted(studies_dir.glob("*.json")):
        yield path


def output_suffix_with_dot(output_suffix: str) -> str:
    return output_suffix if output_suffix.startswith(".") else f".{output_suffix}"


def process_review(review_dir: Path) -> dict:
    source_review_path = review_dir / "sr" / "source_review.json"
    source_review = load_json(source_review_path)
    sr_pico = normalize_sr_pico(source_review.get("pico"))
    included_items = (
        source_review.get("characteristics_of_studies", {}).get("included", []) or []
    )
    exact_map, normalized_items = build_characteristic_maps(included_items)

    matched_studies = []
    unmatched_studies = []
    summary = {
        "review_dir": review_dir.name,
        "review_id": source_review.get("id", ""),
        "total_candidate_studies": 0,
        "matched_studies": 0,
        "unmatched_studies": 0,
        "dropped_empty_risk_of_bias": 0,
        "exact_matches": 0,
        "suffix_matches": 0,
        "studies_with_tables": 0,
        "studies_with_rob": 0,
        "paragraph_count": 0,
        "section_count": 0,
        "table_count": 0,
        "xml_parse_failures": 0,
    }

    for study_path in candidate_study_paths(review_dir):
        study_record = load_json(study_path)
        if study_record.get("category") != "included":
            continue
        if study_record.get("content_type") != "xml":
            continue

        summary["total_candidate_studies"] += 1
        normalized_study_id, match_method, characteristic = match_characteristic(
            study_record.get("study_id", ""),
            exact_map,
            normalized_items,
        )
        if characteristic is None:
            unmatched_record = build_unmatched_study_record(
                study_record,
                normalized_study_id,
                "characteristics_not_matched",
            )
            unmatched_record["review_id"] = source_review.get("id", "")
            unmatched_record["cd_number"] = source_review.get("cd_number", review_dir.name)
            unmatched_record["review_title"] = source_review.get("title", "")
            unmatched_studies.append(unmatched_record)
            summary["unmatched_studies"] += 1
            continue

        content_path = Path(study_record.get("content_path", ""))
        try:
            xml_content = extract_xml_content(content_path)
        except Exception as exc:
            unmatched_record = build_unmatched_study_record(
                study_record,
                normalized_study_id,
                f"xml_parse_error: {exc}",
            )
            unmatched_record["review_id"] = source_review.get("id", "")
            unmatched_record["cd_number"] = source_review.get("cd_number", review_dir.name)
            unmatched_record["review_title"] = source_review.get("title", "")
            unmatched_studies.append(unmatched_record)
            summary["unmatched_studies"] += 1
            summary["xml_parse_failures"] += 1
            continue

        matched_record = build_matched_study_record(
            study_record,
            normalized_study_id,
            match_method,
            characteristic,
            xml_content,
            sr_pico,
        )
        matched_record["review_id"] = source_review.get("id", "")
        matched_record["cd_number"] = source_review.get("cd_number", review_dir.name)
        matched_record["review_title"] = source_review.get("title", "")
        if not matched_record["risk_of_bias"]:
            summary["dropped_empty_risk_of_bias"] += 1
            continue
        matched_studies.append(matched_record)
        summary["matched_studies"] += 1
        summary["paragraph_count"] += xml_content["_paragraph_count"]
        summary["section_count"] += len(xml_content["sections"])
        summary["table_count"] += len(xml_content["tables"])
        if xml_content["tables"]:
            summary["studies_with_tables"] += 1
        summary["studies_with_rob"] += 1
        if match_method == "exact_normalized":
            summary["exact_matches"] += 1
        elif match_method == "suffix_normalized":
            summary["suffix_matches"] += 1

    output_payload = {
        "review_id": source_review.get("id", ""),
        "cd_number": source_review.get("cd_number", review_dir.name),
        "review_title": source_review.get("title", ""),
        "studies": matched_studies,
        "unmatched_studies": unmatched_studies,
        "summary": summary,
    }
    return output_payload


def summarize_reviews(
    review_outputs: Sequence[dict],
    input_dir: Path,
    output_dir: Path,
    summary_path: Path,
) -> None:
    global_summary = {
        "input_dir": str(input_dir.resolve()),
        "output_dir": str(output_dir.resolve()),
        "reviews_processed": len(review_outputs),
        "total_candidate_studies": 0,
        "matched_studies": 0,
        "unmatched_studies": 0,
        "dropped_empty_risk_of_bias": 0,
        "exact_matches": 0,
        "suffix_matches": 0,
        "studies_with_tables": 0,
        "studies_with_rob": 0,
        "paragraph_count": 0,
        "section_count": 0,
        "table_count": 0,
        "xml_parse_failures": 0,
    }
    review_summaries = []
    for output in review_outputs:
        summary = output["summary"]
        review_summaries.append(summary)
        for key in (
            "total_candidate_studies",
            "matched_studies",
            "unmatched_studies",
            "dropped_empty_risk_of_bias",
            "exact_matches",
            "suffix_matches",
            "studies_with_tables",
            "studies_with_rob",
            "paragraph_count",
            "section_count",
            "table_count",
            "xml_parse_failures",
        ):
            global_summary[key] += summary[key]

    dump_json(
        summary_path,
        {
            "global_summary": global_summary,
            "reviews": review_summaries,
        },
    )


def grouped_filename(record: dict, output_suffix: str) -> str:
    suffix = output_suffix_with_dot(output_suffix)
    pmid = clean_text(record.get("pmid", ""))
    if pmid:
        return f"{pmid}{suffix}"
    pmcid = clean_text(record.get("pmcid", ""))
    if pmcid:
        return f"{pmcid}{suffix}"
    study_key = re.sub(r"[^a-z0-9]+", "_", record.get("study_id_normalized", "")).strip("_")
    review_key = clean_text(record.get("cd_number", "")) or "review"
    return f"{review_key}__{study_key or 'study'}{suffix}"


def write_grouped_study_files(
    review_outputs: Sequence[dict],
    output_dir: Path,
    output_suffix: str,
    unmatched_path: Path,
) -> None:
    grouped: Dict[str, List[dict]] = {}
    unmatched_rows: List[dict] = []
    for output in review_outputs:
        unmatched_rows.extend(output.get("unmatched_studies", []))
        for study in output.get("studies", []):
            filename = grouped_filename(study, output_suffix)
            grouped.setdefault(filename, []).append(study)

    for filename, records in grouped.items():
        payload = records[0] if len(records) == 1 else records
        dump_json(output_dir / filename, payload)

    dump_json(unmatched_path, unmatched_rows)


def main() -> int:
    args = parse_args()
    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)
    summary_path = Path(args.summary_path)
    unmatched_path = Path(args.unmatched_path)
    output_dir.mkdir(parents=True, exist_ok=True)
    review_dirs = list(iter_review_dirs(input_dir))
    if args.limit_reviews is not None:
        review_dirs = review_dirs[: args.limit_reviews]

    review_outputs = []
    for review_dir in review_dirs:
        review_outputs.append(process_review(review_dir))

    write_grouped_study_files(review_outputs, output_dir, args.output_suffix, unmatched_path)
    summarize_reviews(review_outputs, input_dir, output_dir, summary_path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
