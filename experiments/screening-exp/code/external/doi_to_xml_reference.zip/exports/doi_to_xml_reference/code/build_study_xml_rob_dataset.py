#!/usr/bin/env python3

import argparse
import csv
import json
import re
import shutil
import sys
import time
from copy import deepcopy
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import xml.etree.ElementTree as ET


ET.register_namespace("xlink", "http://www.w3.org/1999/xlink")

USER_AGENT = "codex-sr-cleaned/0.2"
PMC_TOOL = "codex"
PMC_EMAIL = "example@example.com"
IDCONV_URL = "https://pmc.ncbi.nlm.nih.gov/tools/idconv/api/v1/articles/"
EFETCH_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"

CATEGORY_TO_RIS_SUFFIX = {
    "included": "included",
    "excluded": "excluded",
    "ongoing": "ongoing",
    "awaiting_classification": "awaiting",
}

PMCID_RE = re.compile(r"\bPMC\d+\b", re.IGNORECASE)
PMID_RE = re.compile(r"\b\d{5,9}\b")
JUDGEMENT_PREFIX = "Domain (judgement): "
SUPPORT_PREFIX = "Domain (support): "
PROJECT_ROOT = Path(__file__).resolve().parent.parent


def default_path(*parts: str) -> str:
    return str(PROJECT_ROOT.joinpath(*parts))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Build an SR-organized dataset with source SR JSON, full data packages, "
            "study-level XML/HTML content, and risk-of-bias JSON files."
        )
    )
    parser.add_argument(
        "--linked-dir",
        default=default_path(
            "data", "cochrane_reviews", "linked_reviews_dedup_doi"
        ),
        help="Directory with study-linked SR JSON files.",
    )
    parser.add_argument(
        "--review-dir",
        default=default_path("data", "cochrane_reviews", "source_reviews"),
        help="Directory with source SR review JSON files.",
    )
    parser.add_argument(
        "--data-package-dir",
        default=default_path("data", "cochrane_data_package", "zip"),
        help="Directory with unpacked Cochrane data packages.",
    )
    parser.add_argument(
        "--output-dir",
        default=default_path("data", "cochrane_reviews", "rob_dataset"),
        help="Target dataset directory.",
    )
    parser.add_argument(
        "--xml-cache-dir",
        default=default_path("data", "cochrane_reviews", "pmc_xml"),
        help="Cache directory for raw PMC XML files.",
    )
    parser.add_argument(
        "--idconv-cache-path",
        default=default_path(
            "data",
            "cochrane_reviews",
            "linked_reviews_dedup_doi_pmc_xml",
            "_idconv_cache.json",
        ),
        help="Path to the DOI->PMID/PMCID cache JSON.",
    )
    parser.add_argument(
        "--xml-index-cache-path",
        default=default_path(
            "data",
            "cochrane_reviews",
            "linked_reviews_dedup_doi_pmc_xml",
            "_pmc_xml_index.json",
        ),
        help="Path to the PMC XML index cache JSON.",
    )
    parser.add_argument(
        "--review-glob",
        default="*.json",
        help="Glob for review files inside linked-dir.",
    )
    parser.add_argument(
        "--limit-reviews",
        type=int,
        default=None,
        help="Optional limit for testing.",
    )
    parser.add_argument(
        "--idconv-batch-size",
        type=int,
        default=100,
        help="Batch size for PMC ID converter requests.",
    )
    parser.add_argument(
        "--efetch-batch-size",
        type=int,
        default=50,
        help="Batch size for PMC XML efetch requests.",
    )
    parser.add_argument(
        "--sleep-seconds",
        type=float,
        default=0.75,
        help="Delay between remote requests.",
    )
    parser.add_argument(
        "--overwrite-output",
        action="store_true",
        help="Overwrite existing dataset files in the output directory.",
    )
    return parser.parse_args()


def normalize_doi(value: str) -> str:
    text = (value or "").strip()
    if not text:
        return ""
    text = text.replace("\ufeff", "").replace("\u200b", "")
    text = re.sub(r"^\s*doi\s*:\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"^\s*https?://(dx\.)?doi\.org/", "", text, flags=re.IGNORECASE)
    return text.strip().rstrip(" .;,").lower()


def slugify_study_id(value: str) -> str:
    text = (value or "").strip().lower()
    text = text.replace("\u2010", "-").replace("\u2011", "-").replace("\u2012", "-")
    text = text.replace("\u2013", "-").replace("\u2014", "-").replace("\u2212", "-")
    text = re.sub(r"\s+", " ", text)
    return text


def safe_filename(value: str, fallback: str) -> str:
    text = slugify_study_id(value) or fallback
    text = text.replace("/", "_")
    text = re.sub(r"[^a-z0-9._ -]+", "_", text)
    text = re.sub(r"\s+", "_", text).strip("._")
    return text or fallback


def doi_slug(doi: str) -> str:
    text = normalize_doi(doi)
    text = text.replace("/", "_")
    text = re.sub(r"[^a-z0-9._-]+", "_", text)
    return text.strip("._") or "doi"


def load_json(path: Path):
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def dump_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


def dump_jsonl(path: Path, rows: Iterable[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False))
            handle.write("\n")


def load_cache(path: Path) -> dict:
    if not path.exists():
        return {}
    return load_json(path)


def save_cache(path: Path, cache: dict) -> None:
    dump_json(path, cache)


def copy_file(src: Path, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)


def copy_tree(src: Path, dest: Path) -> None:
    if not src.exists():
        return
    shutil.copytree(src, dest, dirs_exist_ok=True, ignore=shutil.ignore_patterns(".DS_Store"))


def http_get(
    url: str,
    *,
    timeout: int = 60,
    retries: int = 3,
    accept: Optional[str] = None,
) -> Tuple[bytes, str, dict]:
    headers = {"User-Agent": USER_AGENT}
    if accept:
        headers["Accept"] = accept
    last_error = None
    for attempt in range(1, retries + 1):
        request = Request(url, headers=headers)
        try:
            with urlopen(request, timeout=timeout) as response:
                body = response.read()
                final_url = response.geturl()
                response_headers = {k.lower(): v for k, v in response.headers.items()}
                return body, final_url, response_headers
        except HTTPError as exc:
            last_error = exc
            if exc.code == 400:
                raise
            if attempt == retries:
                raise
            retry_after = exc.headers.get("Retry-After")
            if retry_after and retry_after.isdigit():
                delay = float(retry_after)
            else:
                delay = min(2 ** attempt, 30)
            time.sleep(delay)
        except Exception as exc:  # pragma: no cover - network path
            last_error = exc
            if attempt == retries:
                raise
            time.sleep(min(2 ** (attempt - 1), 8))
    raise RuntimeError(f"Unreachable: {last_error}")


def parse_ris_file(path: Path) -> List[dict]:
    text = path.read_text(encoding="utf-8-sig")
    records: List[dict] = []
    current: Dict[str, List[str]] = {}
    last_tag = None
    for raw_line in text.splitlines():
        line = raw_line.rstrip("\n")
        if not line.strip():
            continue
        if line.startswith("ER"):
            if current:
                records.append(current)
                current = {}
                last_tag = None
            continue
        if len(line) >= 6 and line[2:6] == "  - ":
            tag = line[:2]
            value = line[6:].strip()
            current.setdefault(tag, []).append(value)
            last_tag = tag
            continue
        if last_tag is not None:
            current[last_tag][-1] = f"{current[last_tag][-1]} {line.strip()}".strip()
    if current:
        records.append(current)
    return records


def extract_ids_from_ris_record(record: dict) -> dict:
    doi = ""
    pmid = ""
    pmcid = ""
    study_id = ""
    if record.get("DO"):
        doi = record["DO"][0].strip()
    if record.get("NS"):
        study_id = record["NS"][0].strip()
    for value in record.get("C3", []):
        pmcid_match = PMCID_RE.search(value)
        if pmcid_match and not pmcid:
            pmcid = pmcid_match.group(0).upper()
        if ("PubMed" in value or "PMID" in value) and not pmid:
            pmid_match = PMID_RE.search(value)
            if pmid_match:
                pmid = pmid_match.group(0)
    return {
        "study_id": study_id,
        "doi": normalize_doi(doi),
        "pmid": pmid,
        "pmcid": pmcid,
    }


def build_ris_maps(review_id: str, data_package_dir: Path) -> Dict[str, dict]:
    study_data_dir = data_package_dir / review_id / "study-data"
    result: Dict[str, dict] = {}
    for category, suffix in CATEGORY_TO_RIS_SUFFIX.items():
        path = study_data_dir / f"{review_id}-{suffix}.ris"
        by_study: Dict[str, dict] = {}
        by_doi: Dict[str, dict] = {}
        if path.exists():
            for record in parse_ris_file(path):
                item = extract_ids_from_ris_record(record)
                study_key = slugify_study_id(item["study_id"])
                if study_key:
                    by_study[study_key] = item
                if item["doi"]:
                    by_doi[item["doi"]] = item
        result[category] = {
            "path": path,
            "by_study": by_study,
            "by_doi": by_doi,
        }
    return result


def build_rob_map(review_id: str, data_package_dir: Path) -> Tuple[Path, Dict[str, List[dict]]]:
    csv_path = data_package_dir / review_id / "study-data" / f"{review_id}-risk-of-bias.csv"
    if not csv_path.exists():
        return csv_path, {}
    study_map: Dict[str, List[dict]] = {}
    with csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        headers = reader.fieldnames or []
        domain_names = []
        for header in headers:
            if header.startswith(JUDGEMENT_PREFIX):
                domain_names.append(header[len(JUDGEMENT_PREFIX) :])
        for row in reader:
            study_key = slugify_study_id(row.get("Study", ""))
            if not study_key:
                continue
            domains = []
            for domain in domain_names:
                judgement = (row.get(f"{JUDGEMENT_PREFIX}{domain}") or "").strip()
                support = (row.get(f"{SUPPORT_PREFIX}{domain}") or "").strip()
                if not judgement and not support:
                    continue
                domains.append(
                    {
                        "domain": domain,
                        "judgement": judgement,
                        "support": support,
                        "source_csv": str(csv_path.resolve()),
                    }
                )
            study_map[study_key] = domains
    return csv_path, study_map


def iter_studies(review_data: dict) -> Iterable[Tuple[str, dict]]:
    for category, payload in review_data.get("studies_by_category", {}).items():
        for study in payload.get("studies", []):
            yield category, study


def chunked(items: List[str], size: int) -> Iterable[List[str]]:
    for start in range(0, len(items), size):
        yield items[start : start + size]


def fetch_idconv_batch(dois: List[str]) -> dict:
    params = {
        "ids": ",".join(dois),
        "idtype": "doi",
        "versions": "yes",
        "format": "json",
        "tool": PMC_TOOL,
        "email": PMC_EMAIL,
    }
    url = f"{IDCONV_URL}?{urlencode(params)}"
    try:
        payload = json.loads(http_get(url, timeout=60)[0].decode("utf-8"))
    except HTTPError as exc:
        if exc.code == 400 and len(dois) > 1:
            midpoint = len(dois) // 2
            left = fetch_idconv_batch(dois[:midpoint])
            right = fetch_idconv_batch(dois[midpoint:])
            merged = {}
            merged.update(left)
            merged.update(right)
            return merged
        if exc.code == 400 and len(dois) == 1:
            return {}
        raise
    result = {}
    for record in payload.get("records", []):
        requested = normalize_doi(record.get("requested-id", ""))
        if not requested:
            continue
        result[requested] = {
            "doi": normalize_doi(record.get("doi", requested)),
            "pmid": str(record.get("pmid", "") or ""),
            "pmcid": str(record.get("pmcid", "") or "").upper(),
            "versions": record.get("versions", []),
            "source": "pmc_idconv",
        }
    return result


def article_pmcid(article: ET.Element) -> str:
    for node in article.findall(".//article-id[@pub-id-type='pmcid']"):
        value = (node.text or "").strip().upper()
        if value:
            return value
    return ""


def article_has_body(article: ET.Element) -> bool:
    return article.find("body") is not None


def split_pmc_articles(xml_bytes: bytes) -> Dict[str, dict]:
    root = ET.fromstring(xml_bytes)
    articles = {}
    for article in root.findall("article"):
        pmcid = article_pmcid(article)
        if not pmcid:
            continue
        wrapper = ET.Element("pmc-articleset")
        wrapper.append(deepcopy(article))
        xml_text = ET.tostring(wrapper, encoding="unicode")
        xml_text = '<?xml version="1.0" encoding="UTF-8"?>\n' + xml_text
        articles[pmcid] = {
            "xml_text": xml_text,
            "status": "full_text" if article_has_body(article) else "front_matter_only",
        }
    return articles


def fetch_efetch_batch(pmcids: List[str]) -> Dict[str, dict]:
    params = {
        "db": "pmc",
        "id": ",".join(pmcids),
        "rettype": "xml",
        "tool": PMC_TOOL,
        "email": PMC_EMAIL,
    }
    url = f"{EFETCH_URL}?{urlencode(params)}"
    return split_pmc_articles(http_get(url, timeout=120)[0])


def ensure_xml_cache(
    pmcid: str,
    xml_cache_dir: Path,
    xml_index_cache: dict,
) -> Optional[dict]:
    xml_path = xml_cache_dir / f"{pmcid}.xml"
    entry = xml_index_cache.get(pmcid)
    if entry and Path(entry.get("path", "")).exists():
        return entry
    if xml_path.exists():
        text = xml_path.read_text(encoding="utf-8")
        entry = {
            "path": str(xml_path.resolve()),
            "status": "full_text" if "<body" in text else "front_matter_only",
            "source": "ncbi_efetch",
        }
        xml_index_cache[pmcid] = entry
        return entry
    return None


def fetch_html_fallback(pmid: str, pmcid: str, doi: str) -> Tuple[Optional[bytes], Optional[str], Optional[str], Optional[str]]:
    attempts = []
    if pmcid:
        attempts.append(("pmc_html", f"https://pmc.ncbi.nlm.nih.gov/articles/{pmcid}/", pmcid))
    if pmid:
        attempts.append(("pubmed_html", f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/", pmid))
    if doi:
        attempts.append(("doi_html", f"https://doi.org/{doi}", doi_slug(doi)))
    errors = []
    for source, url, name_part in attempts:
        try:
            body, final_url, headers = http_get(
                url,
                timeout=20,
                retries=1,
                accept="text/html,application/xhtml+xml;q=0.9,*/*;q=0.1",
            )
        except Exception as exc:  # pragma: no cover - network path
            errors.append(f"{source}: {exc}")
            continue
        content_type = headers.get("content-type", "").lower()
        if "html" not in content_type and "xhtml" not in content_type:
            errors.append(f"{source}: unexpected content-type {content_type or 'missing'}")
            continue
        return body, source, name_part, final_url
    return None, None, None, "; ".join(errors) if errors else "no fallback attempts"


def build_study_record(
    *,
    review_file: str,
    review_meta: dict,
    category: str,
    study: dict,
    content_type: str,
    content_source: str,
    content_path: str,
    source_risk_of_bias_csv: str,
    risk_of_bias: List[dict],
) -> dict:
    return {
        "review_id": review_meta.get("id", ""),
        "cd_number": review_meta.get("cd_number", ""),
        "review_file": review_file,
        "study_id": study.get("study_id", ""),
        "category": category,
        "doi": study.get("doi", ""),
        "pmid": study.get("pmid", ""),
        "pmcid": study.get("pmcid", ""),
        "content_type": content_type,
        "content_source": content_source,
        "content_path": content_path,
        "source_review_file": review_file,
        "source_risk_of_bias_csv": source_risk_of_bias_csv,
        "risk_of_bias": risk_of_bias,
    }


def has_network_connectivity() -> bool:
    try:
        http_get("https://pmc.ncbi.nlm.nih.gov/", timeout=10, retries=1, accept="text/html")
        return True
    except Exception:
        return False


def main() -> int:
    args = parse_args()
    linked_dir = Path(args.linked_dir)
    review_dir = Path(args.review_dir)
    data_package_dir = Path(args.data_package_dir)
    output_dir = Path(args.output_dir)
    xml_cache_dir = Path(args.xml_cache_dir)
    idconv_cache_path = Path(args.idconv_cache_path)
    xml_index_cache_path = Path(args.xml_index_cache_path)

    xml_cache_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)

    idconv_cache = load_cache(idconv_cache_path)
    xml_index_cache = load_cache(xml_index_cache_path)
    network_enabled = has_network_connectivity()

    review_paths = sorted(
        path for path in linked_dir.glob(args.review_glob) if path.is_file() and not path.name.startswith("_")
    )
    if args.limit_reviews is not None:
        review_paths = review_paths[: args.limit_reviews]

    review_contexts = []
    pending_dois: List[str] = []
    pending_doi_set = set()
    unique_pmcids = set()

    global_summary = {
        "reviews_processed": 0,
        "studies_with_doi": 0,
        "xml_success": 0,
        "html_fallback_success": 0,
        "content_missing": 0,
        "studies_with_rob": 0,
        "studies_without_rob": 0,
        "data_package_missing_reviews": 0,
        "network_warnings": [],
        "network_enabled": network_enabled,
    }

    for linked_review_path in review_paths:
        linked_review = load_json(linked_review_path)
        review_meta = linked_review.get("sr_meta", {})
        sr_id = review_meta.get("cd_number") or linked_review_path.stem.split("_")[0]
        source_review_path = review_dir / linked_review_path.name
        rob_csv_path, rob_map = build_rob_map(sr_id, data_package_dir)
        ris_maps = build_ris_maps(sr_id, data_package_dir)

        studies = []
        for category, study in iter_studies(linked_review):
            study_key = slugify_study_id(study.get("study_id", ""))
            doi = normalize_doi(study.get("doi", ""))
            pmid = str(study.get("pmid", "") or "")
            pmcid = str(study.get("pmcid", "") or "").upper()

            local_match = ris_maps.get(category, {}).get("by_study", {}).get(study_key)
            if local_match is None and doi:
                local_match = ris_maps.get(category, {}).get("by_doi", {}).get(doi)
            if local_match:
                if not doi and local_match.get("doi"):
                    doi = local_match["doi"]
                if not pmid and local_match.get("pmid"):
                    pmid = local_match["pmid"]
                if not pmcid and local_match.get("pmcid"):
                    pmcid = local_match["pmcid"]

            if not doi:
                continue

            global_summary["studies_with_doi"] += 1
            if (not pmid or not pmcid) and doi not in idconv_cache and doi not in pending_doi_set:
                pending_dois.append(doi)
                pending_doi_set.add(doi)

            studies.append(
                {
                    "category": category,
                    "study": study,
                    "study_key": study_key,
                    "doi": doi,
                    "pmid": pmid,
                    "pmcid": pmcid,
                    "risk_of_bias": rob_map.get(study_key, []),
                    "source_risk_of_bias_csv": str(rob_csv_path.resolve()) if rob_csv_path.exists() else "",
                }
            )

        review_contexts.append(
            {
                "sr_id": sr_id,
                "linked_review_path": linked_review_path,
                "source_review_path": source_review_path,
                "review_meta": review_meta,
                "studies": studies,
            }
        )

    if network_enabled:
        for batch in chunked(pending_dois, args.idconv_batch_size):
            try:
                batch_result = fetch_idconv_batch(batch)
            except Exception as exc:  # pragma: no cover - network path
                global_summary["network_warnings"].append(
                    {
                        "stage": "idconv",
                        "batch_size": len(batch),
                        "error": str(exc),
                    }
                )
                continue
            idconv_cache.update(batch_result)
            save_cache(idconv_cache_path, idconv_cache)
            time.sleep(args.sleep_seconds)
    elif pending_dois:
        global_summary["network_warnings"].append(
            {
                "stage": "idconv",
                "batch_size": len(pending_dois),
                "error": "network unavailable; reused existing cache only",
            }
        )

    missing_xml_fetch = []
    for context in review_contexts:
        for item in context["studies"]:
            cache_hit = idconv_cache.get(item["doi"], {})
            if not item["pmid"] and cache_hit.get("pmid"):
                item["pmid"] = cache_hit["pmid"]
            if not item["pmcid"] and cache_hit.get("pmcid"):
                item["pmcid"] = cache_hit["pmcid"]
            item["study"]["doi"] = item["doi"]
            if item["pmid"]:
                item["study"]["pmid"] = item["pmid"]
            if item["pmcid"]:
                item["study"]["pmcid"] = item["pmcid"]
                unique_pmcids.add(item["pmcid"])

    for pmcid in sorted(unique_pmcids):
        entry = ensure_xml_cache(pmcid, xml_cache_dir, xml_index_cache)
        if entry is None:
            missing_xml_fetch.append(pmcid)
    save_cache(xml_index_cache_path, xml_index_cache)

    if network_enabled:
        for batch in chunked(missing_xml_fetch, args.efetch_batch_size):
            try:
                batch_result = fetch_efetch_batch(batch)
            except Exception as exc:  # pragma: no cover - network path
                global_summary["network_warnings"].append(
                    {
                        "stage": "efetch_xml",
                        "batch_size": len(batch),
                        "error": str(exc),
                    }
                )
                continue
            for pmcid, payload in batch_result.items():
                xml_path = xml_cache_dir / f"{pmcid}.xml"
                xml_path.write_text(payload["xml_text"], encoding="utf-8")
                xml_index_cache[pmcid] = {
                    "path": str(xml_path.resolve()),
                    "status": payload["status"],
                    "source": "ncbi_efetch",
                }
            save_cache(xml_index_cache_path, xml_index_cache)
            time.sleep(args.sleep_seconds)
    elif missing_xml_fetch:
        global_summary["network_warnings"].append(
            {
                "stage": "efetch_xml",
                "batch_size": len(missing_xml_fetch),
                "error": "network unavailable; reused existing XML cache only",
            }
        )

    dataset_summary_rows = []
    for context in review_contexts:
        sr_id = context["sr_id"]
        sr_dir = output_dir / sr_id
        xml_out_dir = sr_dir / "xml"
        html_out_dir = sr_dir / "html"
        studies_out_dir = sr_dir / "studies"
        failed_path = sr_dir / "_failed.jsonl"

        if args.overwrite_output and sr_dir.exists():
            shutil.rmtree(sr_dir)
        xml_out_dir.mkdir(parents=True, exist_ok=True)
        html_out_dir.mkdir(parents=True, exist_ok=True)
        studies_out_dir.mkdir(parents=True, exist_ok=True)

        source_review_copy = sr_dir / "sr" / "source_review.json"
        if context["source_review_path"].exists():
            copy_file(context["source_review_path"], source_review_copy)

        data_package_src = data_package_dir / sr_id
        data_package_dest = sr_dir / "data_package"
        if data_package_src.exists():
            copy_tree(data_package_src, data_package_dest)
            data_package_missing = False
        else:
            data_package_missing = True
            global_summary["data_package_missing_reviews"] += 1

        failed_rows = []
        sr_summary = {
            "sr_id": sr_id,
            "review_id": context["review_meta"].get("id", ""),
            "review_title": context["review_meta"].get("title", ""),
            "source_review_file": str(context["source_review_path"].resolve()),
            "source_review_copy_path": str(source_review_copy.resolve()) if source_review_copy.exists() else "",
            "data_package_source_path": str(data_package_src.resolve()),
            "data_package_copy_path": str(data_package_dest.resolve()) if data_package_dest.exists() else "",
            "data_package_missing": data_package_missing,
            "total_studies": 0,
            "xml_success": 0,
            "html_fallback_success": 0,
            "content_missing": 0,
            "studies_with_rob": 0,
            "studies_without_rob": 0,
        }

        for item in context["studies"]:
            sr_summary["total_studies"] += 1
            risk_of_bias = item["risk_of_bias"]
            if risk_of_bias:
                sr_summary["studies_with_rob"] += 1
                global_summary["studies_with_rob"] += 1
            else:
                sr_summary["studies_without_rob"] += 1
                global_summary["studies_without_rob"] += 1

            study = item["study"]
            pmcid = item["pmcid"]
            pmid = item["pmid"]
            doi = item["doi"]
            content_type = "missing"
            content_source = ""
            content_path = ""

            xml_entry = ensure_xml_cache(pmcid, xml_cache_dir, xml_index_cache) if pmcid else None
            if xml_entry and xml_entry.get("status") == "full_text":
                src_xml_path = Path(xml_entry["path"])
                dest_xml_path = xml_out_dir / f"{pmcid}.xml"
                if args.overwrite_output or not dest_xml_path.exists():
                    copy_file(src_xml_path, dest_xml_path)
                content_type = "xml"
                content_source = xml_entry.get("source", "ncbi_efetch")
                content_path = str(dest_xml_path.resolve())
                sr_summary["xml_success"] += 1
                global_summary["xml_success"] += 1
            else:
                if network_enabled:
                    html_bytes, fallback_source, name_part, final_or_error = fetch_html_fallback(pmid, pmcid, doi)
                else:
                    html_bytes, fallback_source, name_part, final_or_error = (
                        None,
                        None,
                        None,
                        "network unavailable; html fallback skipped",
                    )
                if html_bytes and fallback_source and name_part:
                    dest_html_path = html_out_dir / f"{name_part}.html"
                    dest_html_path.write_bytes(html_bytes)
                    content_type = "html"
                    content_source = fallback_source
                    content_path = str(dest_html_path.resolve())
                    sr_summary["html_fallback_success"] += 1
                    global_summary["html_fallback_success"] += 1
                else:
                    sr_summary["content_missing"] += 1
                    global_summary["content_missing"] += 1
                    failed_rows.append(
                        {
                            "review_id": context["review_meta"].get("id", ""),
                            "cd_number": sr_id,
                            "study_id": study.get("study_id", ""),
                            "category": item["category"],
                            "doi": doi,
                            "pmid": pmid,
                            "pmcid": pmcid,
                            "reason": final_or_error or "content fetch failed",
                        }
                    )

            study_filename = safe_filename(study.get("study_id", ""), fallback=doi_slug(doi)) + ".json"
            study_record = build_study_record(
                review_file=context["linked_review_path"].name,
                review_meta=context["review_meta"],
                category=item["category"],
                study=study,
                content_type=content_type,
                content_source=content_source,
                content_path=content_path,
                source_risk_of_bias_csv=item["source_risk_of_bias_csv"],
                risk_of_bias=risk_of_bias,
            )
            dump_json(studies_out_dir / study_filename, study_record)

        dump_json(sr_dir / "_summary.json", sr_summary)
        dump_jsonl(failed_path, failed_rows)
        dataset_summary_rows.append(sr_summary)

    global_summary["reviews_processed"] = len(review_contexts)
    save_cache(xml_index_cache_path, xml_index_cache)
    dump_json(
        output_dir / "_dataset_summary.json",
        {
            "generated_at_epoch": int(time.time()),
            "linked_dir": str(linked_dir.resolve()),
            "review_dir": str(review_dir.resolve()),
            "data_package_dir": str(data_package_dir.resolve()),
            "output_dir": str(output_dir.resolve()),
            "xml_cache_dir": str(xml_cache_dir.resolve()),
            "idconv_cache_path": str(idconv_cache_path.resolve()),
            "xml_index_cache_path": str(xml_index_cache_path.resolve()),
            "global_summary": global_summary,
            "reviews": dataset_summary_rows,
        },
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
